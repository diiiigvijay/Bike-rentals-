package com.rental.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "vehicles")
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String model;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private VehicleType type;

    private String imageUrl;

    @ManyToOne
    @JoinColumn(name = "city_id", nullable = false)
    private City city;

    private Double dailyRate;
    private Double weeklyRate;
    private Double monthlyRate;

    private boolean available = true;

    public enum VehicleType {
        BIKE, SCOOTY
    }
}
