package com.rental;

import com.rental.model.City;
import com.rental.model.PickupPoint;
import com.rental.model.Vehicle;
import com.rental.repository.CityRepository;
import com.rental.repository.PickupPointRepository;
import com.rental.repository.VehicleRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

    private final CityRepository cityRepository;
    private final PickupPointRepository pickupPointRepository;
    private final VehicleRepository vehicleRepository;

    public DataSeeder(CityRepository cityRepository, PickupPointRepository pickupPointRepository, VehicleRepository vehicleRepository) {
        this.cityRepository = cityRepository;
        this.pickupPointRepository = pickupPointRepository;
        this.vehicleRepository = vehicleRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (cityRepository.count() == 0) {
            seedCitiesAndVehicles();
        }
    }

    private void seedCitiesAndVehicles() {
        // Top 20 Indian Cities with approx lat/lon
        Object[][] cityData = {
            {"Mumbai", 19.0760, 72.8777}, {"Delhi", 28.7041, 77.1025}, {"Bangalore", 12.9716, 77.5946},
            {"Hyderabad", 17.3850, 78.4867}, {"Ahmedabad", 23.0225, 72.5714}, {"Chennai", 13.0827, 80.2707},
            {"Kolkata", 22.5726, 88.3639}, {"Surat", 21.1702, 72.8311}, {"Pune", 18.5204, 73.8567},
            {"Jaipur", 26.9124, 75.7873}, {"Lucknow", 26.8467, 80.9462}, {"Kanpur", 26.4499, 80.3319},
            {"Nagpur", 21.1458, 79.0882}, {"Indore", 22.7196, 75.8577}, {"Thane", 19.2183, 72.9781},
            {"Bhopal", 23.2599, 77.4126}, {"Visakhapatnam", 17.6868, 83.2185}, {"Pimpri-Chinchwad", 18.6298, 73.7997},
            {"Patna", 25.5941, 85.1376}, {"Vadodara", 22.3072, 73.1812}
        };

        for (Object[] data : cityData) {
            City city = new City();
            city.setName((String) data[0]);
            city.setLatitude((Double) data[1]);
            city.setLongitude((Double) data[2]);
            city = cityRepository.save(city);

            // Seed Pickup Points (2-3 per city)
            createPickupPoint(city, "Central Station Point", 0.01, 0.01);
            createPickupPoint(city, "Airport Zone", -0.02, -0.02);
            createPickupPoint(city, "City Center Hub", 0.005, -0.005);

            // Seed Vehicles (30 Bikes, 20 Scooties)
            for (int i = 1; i <= 30; i++) {
                createVehicle(city, Vehicle.VehicleType.BIKE, "Sport Bike " + i, 500.0, 3000.0, 10000.0);
            }
            for (int i = 1; i <= 20; i++) {
                createVehicle(city, Vehicle.VehicleType.SCOOTY, "City Scooty " + i, 300.0, 1800.0, 6000.0);
            }
        }
    }

    private void createPickupPoint(City city, String name, double latOffset, double lonOffset) {
        PickupPoint pp = new PickupPoint();
        pp.setName(name);
        pp.setAddress(name + ", " + city.getName());
        pp.setLatitude(city.getLatitude() + latOffset);
        pp.setLongitude(city.getLongitude() + lonOffset);
        pp.setCity(city);
        pickupPointRepository.save(pp);
    }

    private void createVehicle(City city, Vehicle.VehicleType type, String model, double daily, double weekly, double monthly) {
        Vehicle v = new Vehicle();
        v.setCity(city);
        v.setType(type);
        v.setModel(model);
        v.setDailyRate(daily);
        v.setWeeklyRate(weekly);
        v.setMonthlyRate(monthly);
        v.setImageUrl(type == Vehicle.VehicleType.BIKE ? "/images/bike_placeholder.jpg" : "/images/scooty_placeholder.jpg");
        vehicleRepository.save(v);
    }
}
