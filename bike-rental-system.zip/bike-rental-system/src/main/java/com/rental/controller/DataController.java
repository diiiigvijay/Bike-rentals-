package com.rental.controller;

import com.rental.model.City;
import com.rental.model.Vehicle;
import com.rental.service.CityService;
import com.rental.service.VehicleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/data")
public class DataController {
    private final CityService cityService;
    private final VehicleService vehicleService;

    public DataController(CityService cityService, VehicleService vehicleService) {
        this.cityService = cityService;
        this.vehicleService = vehicleService;
    }

    @GetMapping("/cities")
    public List<City> getCities() {
        return cityService.getAllCities();
    }

    @GetMapping("/nearest-city")
    public ResponseEntity<?> getNearestCity(@RequestParam double lat, @RequestParam double lon) {
        City city = cityService.getNearestCity(lat, lon);
        if (city == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(city);
    }

    @GetMapping("/vehicles/{cityId}")
    public List<Vehicle> getVehicles(@PathVariable Long cityId) {
        return vehicleService.getVehiclesByCity(cityId);
    }

    @GetMapping("/vehicle/{id}")
    public ResponseEntity<Vehicle> getVehicle(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(vehicleService.getVehicle(id));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
