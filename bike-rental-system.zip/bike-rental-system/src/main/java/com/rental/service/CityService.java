package com.rental.service;

import com.rental.model.City;
import com.rental.repository.CityRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Comparator;

@Service
public class CityService {
    private final CityRepository cityRepository;

    public CityService(CityRepository cityRepository) {
        this.cityRepository = cityRepository;
    }

    public List<City> getAllCities() {
        return cityRepository.findAll();
    }

    public City getNearestCity(double lat, double lon) {
        return cityRepository.findAll().stream()
                .min(Comparator.comparingDouble(c -> calculateDistance(lat, lon, c.getLatitude(), c.getLongitude())))
                .orElse(null);
    }

    // Haversine formula
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371; // Radius of the earth
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c; // convert to km
    }
}
