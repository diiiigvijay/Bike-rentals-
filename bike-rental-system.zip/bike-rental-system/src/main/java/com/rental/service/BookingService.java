package com.rental.service;

import com.rental.model.Booking;
import com.rental.model.User;
import com.rental.model.Vehicle;
import com.rental.repository.BookingRepository;
import com.rental.repository.UserRepository;
import com.rental.repository.VehicleRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.UUID;

@Service
public class BookingService {
    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final VehicleRepository vehicleRepository;
    private final Path rootLocation = Paths.get("uploads");

    public BookingService(BookingRepository bookingRepository, UserRepository userRepository, VehicleRepository vehicleRepository) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.vehicleRepository = vehicleRepository;
        try {
            Files.createDirectories(rootLocation);
        } catch (IOException e) {
            throw new RuntimeException("Could not initialize storage", e);
        }
    }

    public Booking createBooking(Long userId, Long vehicleId, LocalDate start, LocalDate end, MultipartFile license, MultipartFile pan) throws IOException {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Vehicle vehicle = vehicleRepository.findById(vehicleId).orElseThrow(() -> new RuntimeException("Vehicle not found"));

        String licensePath = saveFile(license);
        String panPath = saveFile(pan);

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setVehicle(vehicle);
        booking.setStartDate(start);
        booking.setEndDate(end);
        booking.setLicenseImagePath(licensePath);
        booking.setPanImagePath(panPath);
        booking.setStatus(Booking.BookingStatus.PENDING);
        
        // Simple calculation logic
        long days = java.time.temporal.ChronoUnit.DAYS.between(start, end) + 1;
        double rate = vehicle.getDailyRate();
        if (days >= 30) rate = vehicle.getMonthlyRate() / 30;
        else if (days >= 7) rate = vehicle.getWeeklyRate() / 7;
        
        booking.setTotalAmount(rate * days);

        return bookingRepository.save(booking);
    }

    private String saveFile(MultipartFile file) throws IOException {
        String filename = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
        Files.copy(file.getInputStream(), rootLocation.resolve(filename));
        return filename;
    }
}
