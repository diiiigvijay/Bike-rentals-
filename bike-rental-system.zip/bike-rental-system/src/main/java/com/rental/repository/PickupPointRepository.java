package com.rental.repository;

import com.rental.model.PickupPoint;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PickupPointRepository extends JpaRepository<PickupPoint, Long> {
    List<PickupPoint> findByCityId(Long cityId);
}
